package com.example.demo.domain.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookDto extends ProductDto{
    private String isbn;
    private String author;
    private String description;
    private String discount;
    private String title;
    private String publisher;
    private String pubdate;
    private String link;
    private String image;

}
