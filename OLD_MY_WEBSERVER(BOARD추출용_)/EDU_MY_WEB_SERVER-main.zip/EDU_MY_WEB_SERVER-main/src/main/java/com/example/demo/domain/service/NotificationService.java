package com.example.demo.domain.service;

import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.dto.Criteria;
import com.example.demo.domain.dto.NotificationDto;
import com.example.demo.domain.dto.PageDto;
import com.example.demo.domain.entity.Board;
import com.example.demo.domain.entity.ImageBoard;
import com.example.demo.domain.entity.Notification;
import com.example.demo.domain.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;


    private String notificationPath = "/notification"; //OS에 로그인한 사용자폴더에 저장



    @Transactional(rollbackFor = Exception.class)
    public void addNotification(NotificationDto dto) throws IOException {
        System.out.println("ImageBoardService's addImage....");

        Authentication authentication =  SecurityContextHolder.getContext().getAuthentication();
        PrincipalDetails principalDetails =(PrincipalDetails)authentication.getPrincipal();
        dto.setUsername(principalDetails.getUsername());



        Notification notification = new Notification();
        notification.setTitle(dto.getTitle());
        notification.setContent(dto.getContent());
        notification.setUsername(dto.getUsername());
        notification.setCreatedAt(LocalDateTime.now());

        notificationRepository.save(notification);
        System.out.println("저장확인 ID : " + notification.getId());


        if(dto.getFiles()!=null)
        {
            //저장 폴더 지정
            String uploadPath = notificationPath + File.separator + dto.getUsername()+File.separator +notification.getId();
            File dir = new File(uploadPath);
            if(!dir.exists()) {
                dir.mkdirs();
            }

            //게시물당 파일은 5장까지만
            List<String> boardlist = new ArrayList<>();

            for(MultipartFile file : dto.getFiles())
            {
                System.out.println("--------------------");
                System.out.println("FILE NAME : " + file.getOriginalFilename());
                System.out.println("FILE SIZE : " + file.getSize() + " Byte");
                System.out.println("--------------------");
                boardlist.add(file.getOriginalFilename());

                File fileobj = new File(uploadPath,file.getOriginalFilename());
                file.transferTo(fileobj);
            }
            notification.setFiles(boardlist);

        }



        notificationRepository.save(notification);


    }

    @Transactional(rollbackFor = Exception.class)

    public Map<String,Object> getNotificationList(Criteria criteria) {

        Map<String,Object> returns = new HashMap<String,Object>();
        int totalcount=(int)notificationRepository.count();


        System.out.println("COUNT  :" + totalcount);

        //PageDto 만들기
        PageDto pagedto = new PageDto(totalcount,criteria);

        //시작 게시물 번호 구하기(수정) - OFFSET
        int offset =(criteria.getPageno()-1) * criteria.getAmount();    //1page = 0, 2page = 10

        List<Notification> list  =  notificationRepository.findBoardAmountStart(pagedto.getCriteria().getAmount(),offset);

        returns.put("list",list);
        returns.put("pageDto",pagedto);


        return returns;

    }

    @Transactional(rollbackFor = Exception.class)
    public Notification getNotification(Long id) {
        return notificationRepository.findById(id).get();

    }
}
