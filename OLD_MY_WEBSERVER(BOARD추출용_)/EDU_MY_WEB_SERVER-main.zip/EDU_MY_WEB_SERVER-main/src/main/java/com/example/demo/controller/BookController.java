package com.example.demo.controller;


import com.example.demo.domain.dto.BookDto;
import com.example.demo.domain.entity.Book;
import com.example.demo.domain.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@Slf4j
@RequestMapping("/book")
public class BookController {


    @Autowired
    private BookService bookService;

    @GetMapping("/list")
    public void list(Model model){
        log.info("GET /book/list");

        List<Book> list =     bookService.getAllBook();
        model.addAttribute("list",list);
    }
    @GetMapping("/read")
    public void read(){
        log.info("GET /book/read");
    }
    @GetMapping("/cart")
    public void cart(){
        log.info("GET /book/cart");
    }
    @GetMapping("/buy")
    public void buy(){
        log.info("GET /book/buy");
    }




}
