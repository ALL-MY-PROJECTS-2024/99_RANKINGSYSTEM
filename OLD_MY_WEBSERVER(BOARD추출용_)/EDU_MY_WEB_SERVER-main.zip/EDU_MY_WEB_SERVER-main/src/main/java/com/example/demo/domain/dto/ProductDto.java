package com.example.demo.domain.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto {

    private String categories;
    private Long productId;
    private String productName;
    private String price;
    private String imageUrl;
    private Long amount;
    private String username;

}
