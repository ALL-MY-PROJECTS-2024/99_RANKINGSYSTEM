package com.example.demo.domain.service;


import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.dto.ProductDto;
import com.example.demo.domain.entity.Book;
import com.example.demo.domain.entity.Cart;
import com.example.demo.domain.entity.Lecture;
import com.example.demo.domain.repository.BookRepository;
import com.example.demo.domain.repository.CartRepository;
import com.example.demo.domain.repository.LectureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private LectureRepository lectureRepository;

    @Transactional(rollbackFor = Exception.class)
    public boolean addCard(ProductDto productDto) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.isAuthenticated()) {

            PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
            String username = principalDetails.getUsername();

            if (productDto.getCategories().equals("book")) {

                Book book = bookRepository.findById(productDto.getProductId()).get();

                Cart cart = new Cart();
                cart.setUsername(username);
                cart.setCategories(productDto.getCategories());
                cart.setProductId(productDto.getProductId());
                cart.setProductName(productDto.getProductName());
                cart.setPrice(productDto.getPrice());
                cart.setImageUrl(productDto.getImageUrl());
                cart.setAmount(productDto.getAmount());
                cart.setRegisterDate(LocalDateTime.now());
                cart.setExpiredDate(LocalDateTime.now().plusDays(7));

                cartRepository.save(cart);

                //원래는 Book 재고량도 감소시켜야되지만 실제 처리할때 추가하도록합니다~
                return cart.getNo() > 0;
            }
            else if (productDto.getCategories().equals("lecture")){
                //Lecture lecture = lectureRepository.findById(productDto.getProductId()).get();
                Cart cart = new Cart();
                cart.setUsername(username);
                cart.setCategories(productDto.getCategories());
                cart.setProductId(productDto.getProductId());
                cart.setProductName(productDto.getProductName());
                cart.setPrice(productDto.getPrice());
                cart.setImageUrl(productDto.getImageUrl());
                cart.setAmount(productDto.getAmount());
                cart.setRegisterDate(LocalDateTime.now());
                cart.setExpiredDate(LocalDateTime.now().plusDays(7));
                cartRepository.save(cart);
                return cart.getNo() > 0;
            }


        }
        return false;
    }
    @Transactional(rollbackFor = Exception.class)
    public List<Cart> getMyCart() {

        List<Cart> list =null;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.isAuthenticated())
        {
            PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
            String username = principalDetails.getUsername();
            list = cartRepository.findAllByusername(username);

        }


        return list;
    }

    @Transactional(rollbackFor = Exception.class)
    public void deleteCart(Long no) {
        Cart cart =   cartRepository.findById(no).get();

        cartRepository.delete(cart);


    }
    @Transactional(rollbackFor = Exception.class)
    public void amountAdd(Long no, Long number) {
        Cart cart =  cartRepository.findById(no).get();
        cart.setAmount(number);

        cartRepository.save(cart);
    }

    public List<Cart> getMyCartByUsername(String username) {
        return cartRepository.findAllByusername(username);
    }
}