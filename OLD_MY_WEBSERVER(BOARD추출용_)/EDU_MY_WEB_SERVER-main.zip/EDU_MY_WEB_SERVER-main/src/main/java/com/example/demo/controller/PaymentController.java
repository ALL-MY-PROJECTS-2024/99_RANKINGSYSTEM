package com.example.demo.controller;


import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.dto.PaymentDto;
import com.example.demo.domain.entity.Cart;
import com.example.demo.domain.entity.Payment;
import com.example.demo.domain.service.CartService;
import com.example.demo.domain.service.PaymentService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.nio.file.attribute.UserPrincipal;
import java.util.List;


// -----------------------------------------------------------
// 결제 조회 관련 내용은 RESTAPI로 요청해야 한다
// -----------------------------------------------------------
// DOCUMENT : https://developers.portone.io/api/rest-v1/payment
// DOCUMNET - AccessToken사용  https://developers.portone.io/docs/ko/api/rest-api-access-token?v=v1#step-03--%ED%86%A0%ED%81%B0-%EC%82%AC%EC%9A%A9%ED%95%98%EA%B8%B0
//
// 관리자(결제내역확인) : https://classic-admin.portone.io/

@Controller
@Slf4j
@RequestMapping("/payment")
public class PaymentController {


    private String accessToken;

    private PortOneResponseData portOneResponseData;



    @Autowired
    private CartService cartService;

    @Autowired
    private PaymentService paymentService;


    @GetMapping("/add")
    public @ResponseBody String add(PaymentDto dto){
        System.out.println("GET /payment/add.."+dto);
        paymentService.savePayment(dto);
        return "Success..";

    }


    @GetMapping("/request")
    public void request_test(Authentication authentication, Model model){


        System.out.println("GET /payment/request");

        PrincipalDetails principalDetails =  (PrincipalDetails)authentication.getPrincipal();
        String username = principalDetails.getUser().getUsername();


        List<Cart> list = cartService.getMyCartByUsername(username);
        int price = 0;
        for(Cart c : list){
            price += c.getAmount()* Integer.parseInt(c.getPrice());
        }
        String paymentTitle = null;
        if(list.size()>1)
            paymentTitle = list.get(0).getProductName()+"외 "+list.size()+" 건";
        else
            paymentTitle = list.get(0).getProductName();

        System.out.println("paymentTitle : "+paymentTitle);
        model.addAttribute("paymentTitle",paymentTitle);
        model.addAttribute("paymentTotalPrice", price);
        model.addAttribute("amount", list.size());


    }

    //나의 결제 내역
    @GetMapping("/my")
    public void mypayment(Authentication authentication , Model model){
        log.info("GET /paymnet/my");

        PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
        String username = principalDetails.getUsername();
        List<Payment> list =  paymentService.getMyPaymentInfo(username);
        model.addAttribute("list",list);

    }


    //
    //  PortOne AccessToken 받기
    //
    @GetMapping("/getAccessToken")
    public @ResponseBody String getAccessToken(){
        log.info("GET /payment/getAccessToken ");

        //URL
        String url = "https://api.iamport.kr/users/getToken";
        //Header
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        //Parameter
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("imp_key","1546549255738924");
        params.add("imp_secret","Zjy29fdoI6cNNwIZYMrDX4dkLCLvf6HFyFbbVCNwlRD5YzHCEQV4onWbydWFVbT1ID1Zw0Kp6POYsvKg");


        //header + parameter
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params,headers);

        //Request_Case1
//      RestTemplate rt = new RestTemplate();
//      ResponseEntity<String> response =  rt.exchange(url, HttpMethod.POST,entity,String.class);
//
//      System.out.println(response);
//      System.out.println(response.getBody());

        //Request_Case2
        RestTemplate rt = new RestTemplate();
        PortOneResponseData response =  rt.postForObject(url,entity,PortOneResponseData.class);
        System.out.println(response);
        this.portOneResponseData = response;

        return "";
    }




    @GetMapping("/cancel/{imp_uid}")
    public @ResponseBody ResponseEntity<String> Cancel(@PathVariable String imp_uid){
        log.info("GET /payment/cancel ..." + imp_uid);
        getAccessToken();
        log.info("AccessToken : " + portOneResponseData.getResponse().getAccess_token());
        String accessToken = portOneResponseData.getResponse().getAccess_token();
        //URL
        String url = "https://api.iamport.kr/payments/cancel";
        //Header
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        headers.add("Authorization", "Bearer " + accessToken);
        //Parameter
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("imp_uid",imp_uid);

        //header + parameter
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(params,headers);

        //Request_Case1
        RestTemplate rt = new RestTemplate();
        ResponseEntity<String> response =  rt.exchange(url, HttpMethod.POST,entity,String.class);
        System.out.println(response);
        System.out.println(response.getBody());

        //Db 삭제
        paymentService.removePayment(imp_uid);


         return new ResponseEntity("success", HttpStatus.OK);
    }


}


//Access Token 받기 위한 클래스
@Data
class PortOneResponseData{
    public int code;
    public Object message;
    public Response response;

    @Data
    class Response{
        public String access_token;
        public int now;
        public int expired_at;
    }
}


