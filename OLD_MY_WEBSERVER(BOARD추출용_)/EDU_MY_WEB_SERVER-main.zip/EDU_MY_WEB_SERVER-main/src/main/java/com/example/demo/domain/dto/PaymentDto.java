package com.example.demo.domain.dto;

import lombok.Data;

@Data
public class PaymentDto {
    private String imp_uid ;
    private String merchant_uid;
    private String pay_method;
    private String name;
    private String paid_amount;
    private String status;
}
