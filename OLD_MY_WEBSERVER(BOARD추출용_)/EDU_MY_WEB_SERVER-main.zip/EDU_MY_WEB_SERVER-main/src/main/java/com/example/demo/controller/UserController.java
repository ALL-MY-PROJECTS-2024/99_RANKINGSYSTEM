package com.example.demo.controller;

import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.UserRepository;
import com.example.demo.domain.service.UserService;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.Multipart;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

@Controller
@Slf4j
@RequestMapping("/user")
public class UserController {



	@Autowired
	private UserService userService;

	@Autowired
	private PasswordEncoder passwordEncoder;



	@GetMapping("/login")
	public void login_get(){

	}
	@GetMapping("/certification")
	public void certification(){
		log.info("GET /user/certification...");
	}
	@GetMapping("/join")
	public void join_get() {
		log.info("GET /join");
	}


	@PostMapping("/join")
	public String join_post(@Valid UserDto dto, BindingResult bindingResult, Model model, HttpServletRequest request, HttpServletResponse response) {
		log.info("POST /join "+dto);

		//01

		//02
		if(bindingResult.hasFieldErrors()) {
			for( FieldError error  : bindingResult.getFieldErrors()) {
				log.info(error.getField()+ " : " + error.getDefaultMessage());
				model.addAttribute(error.getField(), error.getDefaultMessage());

			}
			return "user/join";
		}

		//03
		boolean isjoin =  userService.joinMember(dto,model,request);
		if(!isjoin){
			return "user/join";
		}

		//04
		return "redirect:/login?msg=Join_Success!";

	}

	//----------------------------------------------------------------
	//메일인증
	//----------------------------------------------------------------
	@GetMapping(value="/auth/email/{username}")
	public @ResponseBody void email_auth(@PathVariable String username,HttpServletRequest request)
	{
		log.info("GET /user/auth/email.." + username);

		//메일설정
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);
		mailSender.setUsername("jwg135790@gmail.com");
		mailSender.setPassword("wmgj xbbl jtds nnaa");

		Properties props = new Properties();
		props.put("mail.smtp.auth","true");
		props.put("mail.smtp.starttls.enable","true");
		mailSender.setJavaMailProperties(props);

		//난수값생성
		String tmpPassword = (int)(Math.random()*10000000)+""; //

		//본문내용 설정
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(username);
		message.setSubject("[WEB_TEST]이메일코드발송");
		message.setText(tmpPassword);

		//발송
		mailSender.send(message);

		//세션에 Code저장
		HttpSession session = request.getSession();
		session.setAttribute("email_auth_code",tmpPassword);

	}



	@GetMapping("/auth/confirm/{code}")
	public @ResponseBody String email_auth_confirm(@PathVariable String code,HttpServletRequest request)
	{
		System.out.println("GET /user/auth/confirm " + code);
		HttpSession session = request.getSession();
		String auth_code = (String)session.getAttribute("email_auth_code");
		if(auth_code!=null)
		{
			if(auth_code.equals(code)){
				session.setAttribute("is_email_auth",true);
				return "success";
			}else{
				session.setAttribute("is_email_auth",false);
				return "failure";
			}

		}

		return "failure";
	}


	@GetMapping("/mypage")
	public void mypage(Authentication authentication, Model model)
	{
		log.info("GET /user/mypage..");

		PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
		UserDto userDto = principalDetails.getUser();


		model.addAttribute("userDto",principalDetails.getUser());
	}

	@PostMapping("/passwordConfirm")
	public ResponseEntity<String> passwordConfirmFunction(@RequestBody JSONObject oldPassword, Authentication authentication){
		System.out.println("POST  /user/passwordConfirm .." + oldPassword.get("oldPassword"));
		PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
		UserDto userDto = principalDetails.getUser();

		boolean isCorrect =  passwordEncoder.matches(oldPassword.get("oldPassword").toString(),userDto.getPassword());

		if(isCorrect) {
			System.out.println("패스워드 일치!");
			//여기서 패스워드가 일치한다면 패스워드 확인이 완료되었다는 정보를 서버측에 저장 Session이 적당한듯..(코드는 나중에 넣어야지..피고나니까)
			return new ResponseEntity("패스워드 확인 완료",HttpStatus.OK);

		}
		return new ResponseEntity("패스워드 불일치", HttpStatus.UNAUTHORIZED);



	}




	//프로필이미지 업로드

	@Autowired
	private ResourceLoader resourceLoader;

	@PostMapping(value="/profileimage/upload")
	public @ResponseBody String profileimageUpload(@RequestBody MultipartFile[] file,Authentication authentication) throws IOException {
		log.info("POST  /user/profileimage/upload file : " + file);



		//폴더 경로 확인
		// private String imageBoardPath = "/profileimage";

//		Resource resource = resourceLoader.getResource("classpath:static/images/user");
//		File getfiles = resource.getFile();
//		String absolutePath = getfiles.getAbsolutePath();
		String absolutePath = "/profileimage";
		System.out.println("정적 자원 경로: " + absolutePath);


		//접속 유저명 받기
		PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
		UserDto userDto = principalDetails.getUser();
		String username = userDto.getUsername();

		//저장 폴더 지정
		String uploadPath = absolutePath +"/" + username;
		File dir = new File(uploadPath);
		if(!dir.exists()) {
				dir.mkdirs();
		}
		else
		{
			//기존 파일 제거
			File[] files = dir.listFiles();
			for(File rmfile : files){
				rmfile.delete();
			}
		}


		System.out.println("--------------------");
		System.out.println("FILE NAME : " + file[0].getOriginalFilename());
		System.out.println("FILE SIZE : " + file[0].getSize() + " Byte");
		System.out.println("--------------------");




		//파일명 추출
		String filename = file[0].getOriginalFilename();
		//파일객체 생성
		File fileobj = new File(uploadPath,filename);
		//업로드
		file[0].transferTo(fileobj);


		//Authentication에도 변경 정보 넣기
		// http://localhost:8080/images/user/+username/+filename

		userDto.setProfileimage("/profileimage"+"/" + username + "/" + filename);
		principalDetails.setUser(userDto);

		//DB에도 넣기
		userService.updateProfile(userDto);



		return "ok";

	}








}





