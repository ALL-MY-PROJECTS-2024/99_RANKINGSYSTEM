package com.example.demo.controller;


import com.example.demo.domain.dto.LectureDto;
import com.example.demo.domain.entity.Lecture;
import com.example.demo.domain.service.LectureService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Controller
@Slf4j
@RequestMapping("/lecture")
public class LectureController {

    @Autowired
    private LectureService lectureService;

    @GetMapping("/list")
    public void list(Model model ){
        List<Lecture> list = lectureService.findAll();


        for(int i=1; i<list.size(); i++){
            if(list.get(i).getTitle().equals(list.get(i-1).getTitle()))
                list.remove(i);

        }



        model.addAttribute("list",list);
    }

    @GetMapping("/read")
    public void read(Long lcode,String idx, Model model) {
        List<Lecture> list = lectureService.getLectureInfo(lcode);

        list.stream().forEach(item -> System.out.println(item));

        model.addAttribute("list", list);

        Lecture readDto = list.get(0);


        model.addAttribute("readDto",readDto);

    }
    @GetMapping("/idx")
    public @ResponseBody Lecture idx(Long lcode, String idx){
        Lecture lecture =  lectureService.findIdx(lcode,idx);
        return lecture;

    }


    @GetMapping("/post")
    public void get_add(){

    }
    @PostMapping("/post")
    public String post_add(LectureDto dto){
        System.out.println("POST /lecture/add " + dto);
        lectureService.addLecture(dto);

        return "redirect:/lecture/list";
    }


}
