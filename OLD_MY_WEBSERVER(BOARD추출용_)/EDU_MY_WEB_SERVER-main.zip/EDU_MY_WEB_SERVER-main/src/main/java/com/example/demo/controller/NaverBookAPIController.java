package com.example.demo.controller;

import com.example.demo.domain.dto.BookDto;
import com.example.demo.domain.dto.Criteria;
import com.example.demo.domain.dto.PageDto;
import com.example.demo.domain.service.BookService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;


@Controller
@Slf4j
@RequestMapping("/naverbook")
public class NaverBookAPIController {

    @Value("${spring.security.oauth2.client.registration.naver.client-id}")
    private  String NAVER_CLIENT_ID;
    @Value("${spring.security.oauth2.client.registration.naver.client-secret}")
    private String NAVER_CLIENT_SECRET;


    @Autowired
    private BookService bookService;

    @GetMapping("/list")
    public void String(){
        log.info("GET /book/list..." );

    }

    @GetMapping("/search/{page}/{keyword}")
    public @ResponseBody NaverBookSerachResult image(@PathVariable String page, @PathVariable String keyword){
        log.info("GET /book/search/"+page+"/"+keyword);

        //URL
        String url = "https://openapi.naver.com/v1/search/book.json?query="+keyword+"&display=10&start="+page;
        //Header
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Naver-Client-Id", NAVER_CLIENT_ID);
        headers.add("X-Naver-Client-Secret", NAVER_CLIENT_SECRET);

        //header + parameter
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(headers);

        //Request_Case2
        RestTemplate rt = new RestTemplate();
        ResponseEntity<NaverBookSerachResult> response =  rt.exchange(url, HttpMethod.GET,entity,NaverBookSerachResult.class);
        System.out.println(response.getBody());


        return response.getBody();

    }

    @GetMapping(value = "/createPagenation/{total}/{start}" ,produces= MediaType.APPLICATION_JSON_VALUE )
    public @ResponseBody PageDto getPagenation(@PathVariable int total,@PathVariable int start){
        log.info("GET /createPagenation/total : " + total);

        int pageNo = start;
        int amount = 10;
        Criteria criteria = new Criteria(pageNo,amount);
        PageDto pagedto = new PageDto(total,criteria);
        return pagedto;

    }

    @PostMapping(value="/savebooks")
    public @ResponseBody  String saveBooks(@RequestBody BookDto[] data){
        System.out.println(data.length);
        for(BookDto dto : data)
            System.out.println(dto);

        bookService.dbsave(data);

        return "";
    }

}

@Data
class NaverBookSerachResult {
    private String lastBuildDate;
    private Long total;
    private Long start;
    private Long display;
    ArrayList<JSONObject> items = new ArrayList <JSONObject> ();

}
@Data
class items{
    private String title;
    private String link;
    private String image;
    private String author;
    private String discount;
    private String publisher;
    private String pubdate;
    private String isbn;
    private String description;
}

