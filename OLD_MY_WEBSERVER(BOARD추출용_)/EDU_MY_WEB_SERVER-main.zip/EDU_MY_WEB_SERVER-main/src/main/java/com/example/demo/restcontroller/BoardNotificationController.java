package com.example.demo.restcontroller;


import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.entity.BoardNotification;
import com.example.demo.domain.repository.BoardNotificationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/boardnotification")
@Slf4j
public class BoardNotificationController {

    @Autowired
    private BoardNotificationRepository notificationRepository;

    @GetMapping(value = "/read",produces = MediaType.APPLICATION_JSON_VALUE)
    public  List<BoardNotification> f1(Authentication authentication){
        PrincipalDetails principalDetails = (PrincipalDetails)authentication.getPrincipal();
        String writeusername = principalDetails.getUsername();
        System.out.println("writeusername : " + writeusername);
        List<BoardNotification> list =  notificationRepository.findAllByWriteusername(writeusername);

        //읽음 처리
        for(BoardNotification boardNotification : list) {
            System.out.println(boardNotification);
            boardNotification.setIsread(true);  //읽음처리
            notificationRepository.save(boardNotification);//저장
        }
       return list;

    }
    @GetMapping(value = "/isexist",produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean isexist(Authentication authentication)
    {
        PrincipalDetails principalDetails = (PrincipalDetails)authentication.getPrincipal();
        String writeusername = principalDetails.getUsername();
        System.out.println("writeusername : " + writeusername);
        List<BoardNotification> list =  notificationRepository.findAllByWriteusername(writeusername);

        return list.size()>0;
    }


}
