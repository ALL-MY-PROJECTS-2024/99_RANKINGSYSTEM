package com.example.demo.domain.service;


import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.dto.PaymentDto;
import com.example.demo.domain.entity.Payment;
import com.example.demo.domain.repository.CartRepository;
import com.example.demo.domain.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private CartRepository cartRepository;


    @Transactional(rollbackFor = Exception.class)
    public void savePayment(PaymentDto dto) {


        //Cart에 내용 삭제
        Authentication authentication =  SecurityContextHolder.getContext().getAuthentication();
        PrincipalDetails principalDetails = (PrincipalDetails)authentication.getPrincipal();
        String username = principalDetails.getUsername();
        System.out.println("PAYMENT SERVICE's SAVEPAYMENT ... " + username);
        cartRepository.DeleteAllByusername(username);

        //Payment에 구매정보 저장
        Payment payment = new Payment();
        payment.setImp_uid(dto.getImp_uid());
        payment.setName(dto.getName());
        payment.setPay_method(dto.getPay_method());
        payment.setPaid_amount(dto.getPaid_amount());
        payment.setMerchant_uid(dto.getMerchant_uid());
        payment.setStatus(dto.getStatus());
        payment.setUsername(username);
        paymentRepository.save(payment);


    }

    @Transactional(rollbackFor = Exception.class)
    public List<Payment> getMyPaymentInfo(String username) {
        return paymentRepository.findByUsername(username);

    }

    @Transactional(rollbackFor = Exception.class)
    public void removePayment(String impUid) {
       Payment payment =   paymentRepository.findById(impUid).get();
        paymentRepository.delete(payment);
    }
}
