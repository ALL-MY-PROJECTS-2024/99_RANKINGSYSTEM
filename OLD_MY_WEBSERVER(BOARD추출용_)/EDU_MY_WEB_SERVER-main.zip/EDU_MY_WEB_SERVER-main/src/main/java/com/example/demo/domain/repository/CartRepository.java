package com.example.demo.domain.repository;


import com.example.demo.domain.entity.BoardNotification;
import com.example.demo.domain.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<Cart,Long> {

    @Query("SELECT c FROM Cart c WHERE username = :username ORDER BY no DESC")
    List<Cart> findAllByusername(@Param("username") String username);

    @Modifying
    @Query("DELETE FROM Cart c WHERE c.username = :username")
    void DeleteAllByusername(@Param("username") String username);

}
