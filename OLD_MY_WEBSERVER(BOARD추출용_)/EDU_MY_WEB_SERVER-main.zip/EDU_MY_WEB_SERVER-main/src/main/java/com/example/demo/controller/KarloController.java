package com.example.demo.controller;


import com.example.demo.config.auth.PrincipalDetails;
import com.example.demo.domain.service.UserService;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.awt.*;
import java.util.ArrayList;

@RequestMapping("/karlo")
@Controller
@Slf4j
public class KarloController {


    private KarloResponse karloResponse;
    @Autowired
    private UserService userService;

    @GetMapping("/list")
    public void list(){

    }

    @Value("${spring.security.oauth2.client.registration.kakao.client-id}")
    private String RESTAPI_KEY;

    @GetMapping("/index")
    public void index(){
        System.out.println("GET /th/kakao/karlo/index ");
    }
    @GetMapping("/request/{prompt}")
    public @ResponseBody Object request(@PathVariable("prompt") String prompt)
    {
        System.out.println("GET /th/kakao/karlo/requqest " + prompt);
        //URL
        String url = "https://api.kakaobrain.com/v2/inference/karlo/t2i";
        //Header
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "KakaoAK "+RESTAPI_KEY);

        headers.add("Content-Type", "application/json");


        //Parameter

        JSONObject param = new JSONObject();;
        param.put("prompt",prompt);


        //header + parameter
        HttpEntity<String> entity = new HttpEntity<>(param.toString(),headers);

        //Request_Case1
//        RestTemplate rt = new RestTemplate();
//        ResponseEntity<String> response =  rt.exchange(url, HttpMethod.POST,entity,String.class);
//
//        System.out.println(response);
//        System.out.println(response.getBody());
//
//        return response.getBody();
        //Request_Case2
        RestTemplate rt = new RestTemplate();
        KarloResponse response =  rt.postForObject(url,entity,KarloResponse.class);
        System.out.println(response);
        this.karloResponse = response;
        return karloResponse;
    }


    @GetMapping("/updateprofileimage")
    public  @ResponseBody String updateProfileImage(Authentication authentication)
    {
        System.out.println("GET /karlo/updateprofileimage");
        if(karloResponse!=null)
            System.out.println("IMG URL : " +karloResponse.getImages().get(0));

        PrincipalDetails principalDetails = (PrincipalDetails) authentication.getPrincipal();
        String username = principalDetails.getUsername();


        userService.updateProfileImage(username,karloResponse.getImages().get(0).getImage());

        principalDetails.getUser().setProfileimage(karloResponse.getImages().get(0).getImage());
        return "";
    }

}



@Data
@NoArgsConstructor
@AllArgsConstructor
class KarloResponse{
    public String id;
    public String model_version;
    public ArrayList<Image> images;


}

@Data
@NoArgsConstructor
@AllArgsConstructor
class Image{
    public String id;
    public String image;
    public long seed;
    public JSONObject nsfw_content_detected;
    public JSONObject nsfw_score;
}
