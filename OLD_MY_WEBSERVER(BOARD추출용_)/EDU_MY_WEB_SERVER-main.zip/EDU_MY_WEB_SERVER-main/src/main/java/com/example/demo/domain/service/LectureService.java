package com.example.demo.domain.service;


import com.example.demo.domain.dto.LectureDto;
import com.example.demo.domain.entity.Lecture;
import com.example.demo.domain.repository.LectureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LectureService {
    @Autowired
    private LectureRepository lectureRepository;


    public List<Lecture> getLectureInfo(Long lcode)
    {
       return  lectureRepository.findAllBylcode(lcode);


    }

    public void addLecture(LectureDto dto) {
        Lecture lecture = new Lecture();
        lecture.setTitle(dto.getTitle());
        lecture.setSubtitle(dto.getSubtitle());
        lecture.setIdx(dto.getIdx());
        lecture.setLn(dto.getLn());
        lecture.setLcode(dto.getLcode());
        lecture.setDescription(dto.getDescription());
        lecture.setTeacher(dto.getTeacher());
        lecture.setIlikeit(0L);
        lectureRepository.save(lecture);

    }

    public List<Lecture> findAll() {

        return  lectureRepository.findAll();

    }

    public List<Lecture> getList() {
        return lectureRepository.findAllGroupByTitleAndTeacher();
    }

    public Lecture findIdx(Long lcode, String idx) {
        return lectureRepository.findAllBylcodeAndIdx(lcode, idx);
    }
}
