package com.example.demo.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Lecture {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    Long no;
    Long lcode;
    String idx;
    String ln;
    String description;
    String title;
    String subtitle;
    String playtime;
    String teacher;
    Long ilikeit;

}
