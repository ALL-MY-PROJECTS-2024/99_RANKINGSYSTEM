package com.example.demo.domain.dto;

import lombok.Data;

@Data

public class LectureDto {
    Long no;
    Long lcode;
    String idx;
    String ln;
    String description;
    String title;
    String subtitle;
    String playtime;
    String teacher;
    Long ilikeit;

}
