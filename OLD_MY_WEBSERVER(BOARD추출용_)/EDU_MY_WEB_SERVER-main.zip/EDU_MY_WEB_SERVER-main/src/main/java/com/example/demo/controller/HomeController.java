package com.example.demo.controller;


import com.example.demo.config.auth.PrincipalDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@Slf4j
public class HomeController {

    @GetMapping("/")
    public String home(){
        log.info("/GET /");
        return "index";
    }
    @GetMapping("/login")
    public void login_get(Authentication authentication)
    {



    }
    @GetMapping("/logoutPage")
    public void logoutPage_get()
    {
        log.info("GET /logoutPage");
    }

    @GetMapping("/logout")
    public void logout_get()
    {
        log.info("GET /logout");
    }

    @GetMapping("/templates")
    public void templates(){
        log.info("/GET /templates");
    }



    //나중에 지울것...
    @GetMapping("/footer")
    public void f1(){

    }

}
