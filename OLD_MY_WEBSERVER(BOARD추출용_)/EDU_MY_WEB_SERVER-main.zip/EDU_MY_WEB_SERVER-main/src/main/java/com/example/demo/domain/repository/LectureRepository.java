package com.example.demo.domain.repository;


import com.example.demo.domain.entity.Cart;
import com.example.demo.domain.entity.Lecture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LectureRepository extends JpaRepository<Lecture,Long>{

    @Query("SELECT l FROM Lecture l WHERE lcode = :lcode ORDER BY idx ASC")
    List<Lecture> findAllBylcode(@Param("lcode") Long lcode);

    @Query("SELECT l FROM Lecture l WHERE lcode = :lcode and idx = :idx ORDER BY idx ASC")
    Lecture findAllBylcodeAndIdx(@Param("lcode") Long lcode,@Param("idx") String idx);


    //사용X
    @Query("select L.title,L.teacher,sum(ilikeit) from Lecture L group by title,teacher")
    List<Lecture> findAllGroupByTitleAndTeacher();

}
