package com.example.demo.domain.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Book {


    @Id
    private Long isbn;
    private String author;
    @Column(length = 4096)
    private String description;
    private String discount;
    private String title;
    private String publisher;
    private String pubdate;
    private String link;

    private String image;

}
