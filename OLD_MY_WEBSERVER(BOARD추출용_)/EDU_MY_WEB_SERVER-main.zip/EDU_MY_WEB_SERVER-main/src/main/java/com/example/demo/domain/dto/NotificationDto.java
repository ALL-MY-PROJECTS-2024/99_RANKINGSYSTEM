package com.example.demo.domain.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.Multipart;
import javax.persistence.ElementCollection;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDateTime;
import java.util.List;


@Data
public class NotificationDto {
    private Long id;
    private String username;
    private String title;
    private String content;
    private LocalDateTime createdAt;
    private MultipartFile[] files;	//이미지 파일들




}
