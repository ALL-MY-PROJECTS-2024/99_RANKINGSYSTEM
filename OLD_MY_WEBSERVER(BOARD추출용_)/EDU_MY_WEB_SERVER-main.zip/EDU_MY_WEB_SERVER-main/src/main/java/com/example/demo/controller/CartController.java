package com.example.demo.controller;


import com.example.demo.domain.dto.ProductDto;
import com.example.demo.domain.entity.Cart;
import com.example.demo.domain.service.CartService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Slf4j
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    private int totalPrice=0;

    @GetMapping("/list")
    public void list(Model model){
        totalPrice = 0;
        List<Cart> list = cartService.getMyCart();
        list.stream().forEach(item->{
            totalPrice += Integer.parseInt(item.getPrice()) * item.getAmount();
        });

        model.addAttribute("list",list);
        model.addAttribute("totalPrice",totalPrice);

    }

    @GetMapping("/add")
    public @ResponseBody ResponseEntity<String> add(ProductDto productDto){

        System.out.println("GET /cart/add ..."+productDto);
        //기본 수량 1개  cart서비스 가서 추가가능하도록 ㅎㅎ

        productDto.setAmount(1L);
        boolean isadded = cartService.addCard(productDto);

        if(isadded)
            return new ResponseEntity<>("success..", HttpStatus.OK);;

        return new ResponseEntity<>("failed..", HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/delete/{no}")
    public @ResponseBody void delete(@PathVariable Long no){
        cartService.deleteCart(no);
    }

    @GetMapping("/plus/{no}/{number}")
    public @ResponseBody void amountadd(@PathVariable Long no,@PathVariable Long number)
    {
        cartService.amountAdd(no,number);
    }

}
