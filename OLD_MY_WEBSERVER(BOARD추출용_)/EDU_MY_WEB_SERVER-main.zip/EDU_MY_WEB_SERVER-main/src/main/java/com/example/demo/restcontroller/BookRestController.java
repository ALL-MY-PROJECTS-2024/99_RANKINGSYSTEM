package com.example.demo.restcontroller;


import com.example.demo.domain.dto.BookDto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/book")
public class BookRestController {

    @GetMapping("/detail")
    public void bookdetails(@RequestParam BookDto dto){


    }


}
