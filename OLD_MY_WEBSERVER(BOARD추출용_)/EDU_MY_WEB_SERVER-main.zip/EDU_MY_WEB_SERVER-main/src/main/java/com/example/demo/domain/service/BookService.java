package com.example.demo.domain.service;


import com.example.demo.domain.dto.BookDto;
import com.example.demo.domain.entity.Book;
import com.example.demo.domain.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;


    @Transactional(rollbackFor = Exception.class)
    public void dbsave(BookDto[] bookdatas){

        for(BookDto dto : bookdatas) {
            Book book = new Book();
            book.setAuthor(dto.getAuthor());
            book.setIsbn(Long.parseLong(dto.getIsbn()));
            book.setDiscount(dto.getDiscount());
            book.setImage(dto.getImage());
            book.setTitle(dto.getTitle());
            book.setLink(dto.getLink());
            book.setPublisher(dto.getPublisher());
            book.setDescription(dto.getDescription());
            book.setPubdate(dto.getPubdate());
            bookRepository.save(book);

        }
    }

    @Transactional(rollbackFor = Exception.class)

    public List<Book> getAllBook() {
        return bookRepository.findAll();

    }
}
